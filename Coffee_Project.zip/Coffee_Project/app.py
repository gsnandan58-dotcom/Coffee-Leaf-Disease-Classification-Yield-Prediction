from flask import Flask, render_template, request, redirect, session
from ultralytics import YOLO
import os
import pandas as pd
import joblib
import uuid

# ✅ App Initialization
app = Flask(__name__)
app.secret_key = "coffee_ai_secret"   # ✅ REQUIRED for session

# Create uploads folder
os.makedirs("static/uploads", exist_ok=True)

# Load models
model = YOLO("model/best.pt")
yield_model = joblib.load("model/yield_model.pkl")

# 🌿 Disease Solutions
disease_solutions = {
    "healthy": "The plant is healthy. Maintain proper care.",
    "leaf miner": "Use neem oil or spinosad spray. Remove infected leaves.",
    "leaf rust": "Apply copper fungicide and reduce humidity.",
    "brown eye spot": "Use mancozeb or chlorothalonil fungicide."
}

# ---------------- LOGIN PAGE ----------------
@app.route('/')
def login():
    return render_template("login.html")


@app.route('/login', methods=['POST'])
def login_user():
    username = request.form['username']
    password = request.form['password']

    if username == "admin" and password == "1234":
        return redirect("/home")
    else:
        return render_template("login.html", error="Invalid Username or Password")


# ---------------- HOME PAGE ----------------
@app.route('/home')
def home():
    return render_template("home.html")


# ---------------- ABOUT PAGE ----------------
@app.route('/about')
def about():
    return render_template("about.html")


# ---------------- DISEASE PAGE ----------------
@app.route('/disease')
def disease():
    return render_template("disease.html")


# ---------------- DISEASE PREDICTION ----------------
@app.route('/predict_disease', methods=['POST'])
def predict_disease():

    if 'image' not in request.files:
        return "No file uploaded"

    file = request.files['image']

    if file.filename == '':
        return "No selected file"

    # Save image
    filename = str(uuid.uuid4()) + "_" + file.filename
    filepath = os.path.join("static/uploads", filename)
    file.save(filepath)

    # YOLO Prediction
    results = model(filepath, save=True)

    label = "No detection"
    confidence = 0

    for r in results:
        if r.boxes is not None and len(r.boxes.cls) > 0:
            cls_id = int(r.boxes.cls[0])
            conf = float(r.boxes.conf[0])

            label = model.names[cls_id]
            confidence = round(conf * 100, 2)

    clean_label = label.lower().replace("_", " ")
    solution = disease_solutions.get(clean_label, "No solution available")

    return render_template("disease.html",
                           prediction=label,
                           confidence=confidence,
                           solution=solution,
                           image_path=filepath)


# ---------------- YIELD PAGE ----------------
@app.route('/yield')
def yield_page():
    history = session.get("history", [])
    return render_template("yield.html", history=history)


# ---------------- YIELD PREDICTION ----------------
@app.route('/predict_yield', methods=['POST'])
def predict_yield():

    try:
        # Get values
        temp = float(request.form['temperature'])
        rain = float(request.form['rainfall'])
        hum = float(request.form['humidity'])
        disease = int(request.form['disease'])

        # Prepare input
        input_data = pd.DataFrame([[temp, rain, hum, disease]],
                                  columns=["temperature", "rainfall", "humidity", "disease"])

        # Prediction
        yield_pred = yield_model.predict(input_data)[0]
        yield_pred = round(yield_pred, 2)

        # ---------------- HISTORY ----------------
        history = session.get("history", [])

        history.append(yield_pred)

        # Keep last 10 values
        if len(history) > 10:
            history.pop(0)

        session["history"] = history

        # ---------------- RETURN ----------------
        return render_template("yield.html",
                               yield_result=yield_pred,
                               history=history,
                               temp=temp,
                               rain=rain,
                               hum=hum,
                               disease=disease)

    except Exception as e:
        print("Error:", e)
        return render_template("yield.html",
                               yield_result="Invalid input",
                               history=session.get("history", []))


# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)
import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib

# Load dataset
df = pd.read_csv("yield_dataset.csv")

# Input features
X = df[["temperature", "rainfall", "humidity", "disease"]]

# Output
y = df["yield"]

# Train model
model = LinearRegression()
model.fit(X, y)

# Save model
joblib.dump(model, "model/yield_model.pkl")

print("Model trained successfully ✅")